package com.example.newapp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

// --------------------------
// Shared UI Components
// --------------------------

@Composable
fun ScreenTitle(text: String) {
    Text(
        text = text,
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        textAlign = TextAlign.Center
    )
}

@Composable
fun InputField(value: String, onValueChange: (String) -> Unit, placeholder: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder) },
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp)
    )
}

@Composable
fun StyledButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 12.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(text, fontSize = 18.sp)
    }
}

@Composable
fun GridItem(row: Int, column: Int) {
    Box(
        modifier = Modifier
            .padding(4.dp)
            .size(90.dp)
            .background(Color(0xFFBBDEFB), RoundedCornerShape(8.dp))
            .border(1.dp, Color.Black, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "Item [$row][$column]", fontSize = 14.sp, color = Color.Black)
    }
}

// --------------------------
// Screens
// --------------------------

@Composable
fun InsertRowsScreen(navController: NavHostController) {
    var rows by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenTitle("Insert Rows")
        Spacer(Modifier.height(16.dp))
        InputField(value = rows, onValueChange = { rows = it }, placeholder = "Enter number of rows")
        Spacer(Modifier.height(16.dp))
        StyledButton("Next") {
            val rowCount = rows.toIntOrNull() ?: 0
            if (rowCount > 0) {
                navController.navigate("insertColumns/$rowCount")
            }
        }
    }
}

@Composable
fun InsertColumnsScreen(navController: NavHostController, rows: Int) {
    var columns by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenTitle("Insert Columns")
        Spacer(Modifier.height(16.dp))
        InputField(value = columns, onValueChange = { columns = it }, placeholder = "Enter number of columns")
        Spacer(Modifier.height(16.dp))
        StyledButton("Show Grid") {
            val colCount = columns.toIntOrNull() ?: 0
            if (colCount > 0) {
                navController.navigate("grid/$rows/$colCount")
            }
        }
        StyledButton("Back") { navController.popBackStack() }
    }
}

@Composable
fun GridScreen(navController: NavHostController, rows: Int, columns: Int) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        ScreenTitle("Grid: $rows x $columns")

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(8.dp)
        ) {
            items(rows) { row ->
                LazyRow {
                    items(columns) { col ->
                        GridItem(row + 1, col + 1)
                    }
                }
            }
        }

        StyledButton("Back") { navController.popBackStack() }
    }
}

// --------------------------
// Navigation Setup
// --------------------------

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "insertRows") {

        composable("insertRows") {
            InsertRowsScreen(navController)
        }

        composable(
            "insertColumns/{rows}",
            arguments = listOf(navArgument("rows") { type = NavType.IntType })
        ) { backStackEntry ->
            val rows = backStackEntry.arguments?.getInt("rows") ?: 0
            InsertColumnsScreen(navController, rows)
        }

        composable(
            "grid/{rows}/{columns}",
            arguments = listOf(
                navArgument("rows") { type = NavType.IntType },
                navArgument("columns") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val rows = backStackEntry.arguments?.getInt("rows") ?: 0
            val columns = backStackEntry.arguments?.getInt("columns") ?: 0
            GridScreen(navController, rows, columns)
        }
    }
}
